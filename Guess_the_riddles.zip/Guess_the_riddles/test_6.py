import gradio as gr

def insert_hello():
    # 直接返回预设文本"Hello"
    return "Hello"

def insert_goodbye():
    # 直接返回预设文本"Goodbye"
    return "Goodbye"

def user_text(text):
    # 用户输入文本时调用此函数，直接返回用户输入的文本
    return text

with gr.Blocks() as demo:
    with gr.Row():
        text_input = gr.Textbox(label="您的文本")
        hello_btn = gr.Button("插入 'Hello'")
        goodbye_btn = gr.Button("插入 'Goodbye'")
        
    hello_btn.click(fn=insert_hello, inputs=[], outputs=text_input)
    goodbye_btn.click(fn=insert_goodbye, inputs=[], outputs=text_input)
    text_input.change(fn=user_text, inputs=text_input, outputs=text_input)

demo.launch()
