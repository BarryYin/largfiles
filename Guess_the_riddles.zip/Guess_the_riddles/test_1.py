import gradio as gr

def update_to_hello(state):
    return "Hello", state

def update_to_goodbye(state):
    return "Goodbye", state

with gr.Blocks() as demo:
    text_state = gr.State(value="初始文本")
    text_input = gr.Textbox(label="可变文本框", value=text_state)
    btn_hello = gr.Button("设置为 'Hello'")
    btn_goodbye = gr.Button("设置为 'Goodbye'")
    
    btn_hello.click(fn=update_to_hello, inputs=text_state, outputs=[text_input, text_state])
    btn_goodbye.click(fn=update_to_goodbye, inputs=text_state, outputs=[text_input, text_state])

demo.launch()