import os
import json
import random
import shutil
import traceback
import hashlib
from PIL import Image
import gradio as gr
from gradio.components import Chatbot
import time
import threading
import agentscope
from agentscope.agents import DialogAgent
from agentscope.agents.user_agent import UserAgent
from agentscope.message import Msg

api_key = os.getenv('AppKey')



def generate_image_from_name(name):
    hash_func = hashlib.md5()
    hash_func.update(name.encode('utf-8'))
    hash_value = hash_func.hexdigest()

    color_hex = '#' + hash_value[:6]
    color_rgb = Image.new('RGB', (1, 1), color_hex).getpixel((0, 0))

    image_filepath =  f"{name}_image.png"
    if os.path.exists(image_filepath):
        print(f"Image already exists at {image_filepath}")
        return image_filepath
    # generate image
    width, height = 200, 200
    image = Image.new('RGB', (width, height), color_rgb)
    # save image
    image.save(image_filepath)
    return image_filepath

def format_cover_html():
    image_src = './guess.jpg' 
    return f"""
<div class="bot_cover">
    <div class="bot_avatar">
        <img src={image_src} />
    </div>
    <div class="bot_name">{"猜谜语大挑战"}</div>
    <div class="bot_desp">{"猜谜语大挑战"}</div>
</div>
"""

# 读取配置文件
with open('./model_configs.json', 'r') as f:
    configs = json.load(f)

# 替换 API key
for config in configs:
    if config['api_key'] == 'YOUR_API_KEY':
        config['api_key'] = api_key

pre_host_key = ''
agents = agentscope.init(
        model_configs= configs,
        agent_configs="./agent_configs.json",
    )

host_agent = agents[0]
judge_agent = agents[1]
parti_agent = agents[2]
user_agent = UserAgent()
host_avatar = generate_image_from_name(host_agent.name)
judge_avatar = generate_image_from_name(judge_agent.name)
parti_avatar = generate_image_from_name(parti_agent.name)
user_avatar = generate_image_from_name('user')

uid = threading.current_thread().name

def init_user(state):
    # seed = state.get('session_seed', random.randint(0, 1000000000))
    user_agent = UserAgent()
    state['user_agent'] = user_agent
    return state

# 创建 Gradio 界面
customTheme = gr.themes.Default(primary_hue=gr.themes.utils.colors.blue, radius_size=gr.themes.utils.sizes.radius_none)

demo = gr.Blocks(css='appBot.css', theme=customTheme)
with demo:
    gr.Markdown('# <center> \N{fire} Powered by Agentscope</center>')
    state = gr.State({'session_seed': uid})
    with gr.Row(elem_classes='container'):
        with gr.Column(scale=4):
            with gr.Column():
                user_chatbot = Chatbot(
                    value=[[None, '系统指挥官提示：您好，欢迎来到猜谜语大挑战，如果你准备好了，请回答开始']],
                    elem_id='user_chatbot',
                    elem_classes=['markdown-body'],
                    avatar_images=[user_avatar, host_avatar, judge_avatar, parti_avatar],
                    height=600,
                    latex_delimiters=[],
                    show_label=False)
            with gr.Row():
                with gr.Column(scale=12):
                    preview_chat_input = gr.Textbox(
                        show_label=False,
                        container=False,
                        placeholder='开始')
                with gr.Column(min_width=70, scale=1):
                    preview_send_button = gr.Button('发送', variant='primary')

        with gr.Column(scale=1):
            user_chat_bot_cover = gr.HTML(format_cover_html())
            
    def send_message(chatbot, input, _state):
        # 将发送的消息添加到聊天历史
        user_agent = _state['user_agent']
        chatbot.append(("用户输入：" + input, ''))
        yield {
            user_chatbot: chatbot,
            preview_chat_input: '',
        }
        if '开始' == input or '继续' == input:
            # 开始处理
            msg = Msg(name="system", content="系统指挥官：猜谜语游戏规则，请回答你认为符合谜语的答案。下面有请主持人出题。")
            chatbot.append((None, f'{msg.content}'))
            yield {
                user_chatbot: chatbot,
                preview_chat_input: '',
            }
            host_msg = host_agent(msg)
            chatbot.append((None, f"主持人出题：本轮的谜语是{host_msg.content}，请用户答题"))
            yield {
                user_chatbot: chatbot,
                preview_chat_input: '',
            }
            global pre_host_key
            pre_host_key = host_msg.content
        else:
            judge_content = f'主持人的谜语是{pre_host_key}，用户的答案是{input}'
            judge_msg = judge_agent(Msg(name='judge', content=judge_content))
            chatbot.append((None, f"裁判的认定：{judge_msg.content}，请输入继续，可以继续作答；请输入结束，结束本轮游戏"))
            yield {
                user_chatbot: chatbot,
                preview_chat_input: '继续',
            }
            if '结束' not in judge_msg.content:
                parti_content = f'主持人的谜语是{pre_host_key}'
                parti_msg = parti_agent(Msg(name='parti', content=parti_content))
                chatbot.append((None, f"辅助给你答案提示：{parti_msg.content}"))
                yield {
                    user_chatbot: chatbot,
                    preview_chat_input: '继续',
                }

    preview_send_button.click(
        send_message,
        inputs=[user_chatbot, preview_chat_input, state],
        outputs=[user_chatbot, preview_chat_input])

    demo.load(init_user, inputs=[state], outputs=[state])

demo.queue()
demo.launch(share=True)
