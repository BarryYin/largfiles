import os
os.system('pip install -e ./agentscope')
os.system('python app_game.py')