import gradio as gr

def update_input(set_value, _):
    # 直接返回 set_value，以便更新输入框内容为 "Hello" 或 "Goodbye"
    # 返回一个空的 set_value 以便下一次操作不受影响
    return set_value, ""

def btn_click(value):
    # 返回按钮对应的值，并保持 set_value 以更新输入框
    return value, value

with gr.Blocks() as demo:
    with gr.Row():
        user_input = gr.Textbox(label="输入框", placeholder="在这里输入文本")
        set_value = gr.State()  # 使用状态来暂存通过按钮设置的值
        btn_hello = gr.Button("设置为 'Hello'")
        btn_goodbye = gr.Button("设置为 'Goodbye'")
    
    # 设置为 'Hello' 或 'Goodbye' 时，更新 user_input 和 set_value
    btn_hello.click(fn=lambda x: btn_click("Hello"), inputs=set_value, outputs=[user_input, set_value])
    btn_goodbye.click(fn=lambda x: btn_click("Goodbye"), inputs=set_value, outputs=[user_input, set_value])

    # 监听 user_input 的改变，以便在用户手动输入时清空 set_value，防止输入被覆盖
    user_input.change(fn=update_input, inputs=[user_input, set_value], outputs=[user_input, set_value])

demo.launch()
