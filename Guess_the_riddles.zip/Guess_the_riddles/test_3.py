import gradio as gr

def update_input_to_hello(set_value, _):
    return "Hello", "Hello"

def update_input_to_goodbye(set_value, _):
    return "Goodbye", "Goodbye"

def maintain_input(user_input, set_value):
    # 如果 set_value 有值，则优先显示 set_value，并清空它，确保下一次用户输入不被覆盖
    if set_value:
        return "", ""  # 清空 set_value 以便下一次不再覆盖用户输入
    # 否则，直接返回用户当前的输入值
    return user_input, set_value

with gr.Blocks() as demo:
    with gr.Row():
        user_input = gr.Textbox(label="输入框", placeholder="在这里输入文本")
        set_value = gr.State()  # 使用状态来暂存通过按钮设置的值
        btn_hello = gr.Button("设置为 'Hello'")
        btn_goodbye = gr.Button("设置为 'Goodbye'")
    
    btn_hello.click(fn=update_input_to_hello, inputs=[set_value, user_input], outputs=[user_input, set_value])
    btn_goodbye.click(fn=update_input_to_goodbye, inputs=[set_value, user_input], outputs=[user_input, set_value])
    user_input.change(fn=maintain_input, inputs=[user_input, set_value], outputs=[user_input, set_value])

demo.launch()
