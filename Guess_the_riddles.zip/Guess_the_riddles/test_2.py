import gradio as gr

def update_input_to_hello():
    # 返回希望在输入框中显示的值
    return "Hello"

def update_input_to_goodbye():
    # 返回希望在输入框中显示的值
    return "Goodbye"

with gr.Blocks() as demo:
    with gr.Row():
        input_text = gr.Textbox(label="输入框", value="初始文本")
        btn_hello = gr.Button("设置为 'Hello'")
        btn_goodbye = gr.Button("设置为 'Goodbye'")
    
    btn_hello.click(fn=update_input_to_hello, inputs=None, outputs=input_text)
    btn_goodbye.click(fn=update_input_to_goodbye, inputs=None, outputs=input_text)

demo.launch()
