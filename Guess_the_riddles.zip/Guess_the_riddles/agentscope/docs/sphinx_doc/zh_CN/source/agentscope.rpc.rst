RPC package
=======================

rpc\_agent\_client module
-----------------------------------------

.. automodule:: agentscope.rpc.rpc_agent_client
   :members:
   :undoc-members:
   :show-inheritance:


rpc\_agent\_pb2\_grpc module
--------------------------------------------

.. automodule:: agentscope.rpc.rpc_agent_pb2_grpc
   :members:
   :undoc-members:
   :show-inheritance:

