Pipelines package
=============================

pipeline module
-------------------------------------

.. automodule:: agentscope.pipelines.pipeline
   :members:
   :undoc-members:
   :show-inheritance:

functional module
---------------------------------------

.. automodule:: agentscope.pipelines.functional
   :members:
   :undoc-members:
   :show-inheritance:
