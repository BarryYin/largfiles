Agents package
==========================

operator module
-------------------------------

.. automodule:: agentscope.agents.operator
   :members:
   :undoc-members:
   :show-inheritance:

agent module
-------------------------------

.. automodule:: agentscope.agents.agent
   :members:
   :undoc-members:
   :show-inheritance:

rpc_agent module
-------------------------------

.. automodule:: agentscope.agents.rpc_agent
   :members:
   :undoc-members:
   :show-inheritance:

user_agent module
-------------------------------

.. automodule:: agentscope.agents.user_agent
   :members:
   :undoc-members:
   :show-inheritance:

dialog_agent module
-------------------------------

.. automodule:: agentscope.agents.dialog_agent
   :members:
   :undoc-members:
   :show-inheritance:

dict_dialog_agent module
-------------------------------

.. automodule:: agentscope.agents.dict_dialog_agent
   :members:
   :undoc-members:
   :show-inheritance:


text_to_image_agent module
-------------------------------

.. automodule:: agentscope.agents.text_to_image_agent
   :members:
   :undoc-members:
   :show-inheritance: