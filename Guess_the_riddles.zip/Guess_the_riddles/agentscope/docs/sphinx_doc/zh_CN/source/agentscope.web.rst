Web UI package
==========================

app module
-----------------------------

.. automodule:: agentscope.web._app
   :members:
   :show-inheritance:

