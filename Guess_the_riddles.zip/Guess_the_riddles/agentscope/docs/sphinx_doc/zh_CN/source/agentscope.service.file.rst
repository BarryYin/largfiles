File package
================================


common module
--------------------------------------

.. automodule:: agentscope.service.file.common
   :members:
   :undoc-members:
   :show-inheritance:

json module
------------------------------------

.. automodule:: agentscope.service.file.json
   :members:
   :undoc-members:
   :show-inheritance:

text module
------------------------------------

.. automodule:: agentscope.service.file.text
   :members:
   :undoc-members:
   :show-inheritance:

