Text processing package
============================================


summarization module
---------------------------------------------------------

.. automodule:: agentscope.service.text_processing.summarization
   :members:
   :undoc-members:
   :show-inheritance:

