Retrieval package
=====================================


retrieval\_from\_list module
----------------------------------------------------------

.. automodule:: agentscope.service.retrieval.retrieval_from_list
   :members:
   :undoc-members:
   :show-inheritance:

similarity module
-----------------------------------------------

.. automodule:: agentscope.service.retrieval.similarity
   :members:
   :undoc-members:
   :show-inheritance:

