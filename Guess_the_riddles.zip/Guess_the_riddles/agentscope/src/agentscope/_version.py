# -*- coding: utf-8 -*-
""" Version of AgentScope."""

__version__ = "0.0.2"
