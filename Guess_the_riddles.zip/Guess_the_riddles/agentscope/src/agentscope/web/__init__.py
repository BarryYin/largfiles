# -*- coding: utf-8 -*-
"""Import all modules in the web ui package."""

from ._app import init

__all__ = ["init"]
