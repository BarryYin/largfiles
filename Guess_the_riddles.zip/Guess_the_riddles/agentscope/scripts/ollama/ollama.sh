#!/bin/bash

ollama pull llama2