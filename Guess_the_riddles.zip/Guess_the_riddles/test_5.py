import gradio as gr

def update_input(user_input, set_value):
    # 如果 set_value 不为空，说明是按钮点击导致的更新
    if set_value:
        # 返回 set_value 更新输入框，并清空 set_value 以避免影响下次用户输入
        return set_value, ""
    # 如果 set_value 为空，说明是用户的直接输入，只返回用户输入的内容
    return user_input, set_value

def btn_click(value):
    # 当按钮被点击时，返回对应的值更新输入框，并设置 set_value 以指示是按钮点击事件
    return value, value

with gr.Blocks() as demo:
    with gr.Row():
        user_input = gr.Textbox(label="输入框", placeholder="请输入文本")
        set_value = gr.State()  # 使用状态来记录按钮点击事件
        btn_hello = gr.Button("设置为 'Hello'")
        btn_goodbye = gr.Button("设置为 'Goodbye'")
    
    btn_hello.click(fn=lambda: btn_click("Hello"), inputs=None, outputs=[user_input, set_value])
    btn_goodbye.click(fn=lambda: btn_click("Goodbye"), inputs=None, outputs=[user_input, set_value])

    # 当用户直接在输入框中输入时，调用此函数处理输入，此时不应更新 set_value
    user_input.change(fn=update_input, inputs=[user_input, set_value], outputs=[user_input, set_value])

demo.launch()
